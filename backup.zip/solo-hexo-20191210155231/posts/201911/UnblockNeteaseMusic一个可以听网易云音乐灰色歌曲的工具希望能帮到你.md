title: UnblockNeteaseMusic，一个可以听网易云音乐灰色歌曲的工具，希望能帮到你
date: '2019-11-21 18:11:06'
updated: '2019-11-29 17:53:01'
tags: [博客, GitHub]
permalink: /articles/2019/11/21/1574331066094.html
---
![5b404889b1e709efea0ab3e04bfcf926.png](https://img.hacpai.com/file/2019/11/5b404889b1e709efea0ab3e04bfcf926-2d0f4c11.png)

此工具来自Github，点击访问[UnblockNeteaseMusic](https://github.com/nondanee/UnblockNeteaseMusic)


