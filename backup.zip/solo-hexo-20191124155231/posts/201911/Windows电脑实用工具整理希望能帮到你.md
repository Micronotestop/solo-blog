title: Windows电脑实用工具整理，希望能帮到你
date: '2019-11-20 10:15:16'
updated: '2019-11-21 17:12:08'
tags: [博客]
permalink: /articles/2019/11/20/1574216116680.html
---
![eye40631341280.jpg](https://img.hacpai.com/file/2019/11/eye40631341280-51131e5f.jpg)

**一、安全类**
1、火绒：省心、简洁、包括常用工具
[火绒官网](https://www.huorong.cn)

**二、清理类**
1、CCleaner：清理注册表、卸载软件，都OK
[CCleaner官网](https://www.ccleaner.com)

**三、工具类**
1、TreeSize Free
一个硬盘文件占用分析软件，了解自己硬盘使用情况，树状结构展示，建议在Microsoft Store搜索下载
[打开 Microsoft Store](ms-windows-store://home)

2、Bandizip，好用的压缩解压缩软件
[Bandizip官网](http://www.bandisoft.com/bandizip)

3、Honeyview ，是一款快速的图像查看器
速度快、简洁、免费
[Honeyview官网](http://www.bandisoft.com/honeyview)

4、Typora，好用的Markdown工具
[Typora官网](https://www.typora.io)

5、PotPlay，强大的本地视频播放工具
超级好用
[PotPlay官网](https://daumpotplayer.com)
