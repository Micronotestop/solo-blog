title: 好用的Visual Studio Code和一些插件，希望能帮到你
date: '2019-11-29 17:12:44'
updated: '2019-11-29 17:53:13'
tags: [工具, 博客]
permalink: /articles/2019/11/29/1575018764343.html
---
![](https://img.hacpai.com/bing/20191127.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


[**Visual Studio Code官网**](https://code.visualstudio.com/)

VSCode是微软的一个开源的跨平台编辑器，很方便。
一些常用插件：
1、Chinese (Simplified) Language Pack for Visual Studio Code，必装的VS Code 的中文（简体）语言包
2、One Dark Pro，漂亮的暗色主题
3、vscode-icons，精致的文件图标
4、Comment Translate，方便的VSCode 注释翻译
5、Bracket Pair Colorizer 2，利用颜色标识匹配的括号关系
6、Beautify，美化 javascript、JSON、CSS、Sass和 HTML 代码
